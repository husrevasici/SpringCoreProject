package org.javaturk.spring.di.ch01.dependency.association;

public class Professor {
	
	private  Course[] coursesGiven;

}
