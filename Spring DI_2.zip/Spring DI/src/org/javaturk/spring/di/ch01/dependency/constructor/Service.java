package org.javaturk.spring.di.ch01.dependency.constructor;

public class Service {

}
