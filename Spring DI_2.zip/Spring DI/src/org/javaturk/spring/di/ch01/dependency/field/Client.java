package org.javaturk.spring.di.ch01.dependency.field;

public class Client {
	
	private Service service = new Service();

}
