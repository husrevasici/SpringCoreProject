package org.javaturk.spring.di.ch01.dependency.general;

public class Service {

	public void doIt() {
		
	}

}
