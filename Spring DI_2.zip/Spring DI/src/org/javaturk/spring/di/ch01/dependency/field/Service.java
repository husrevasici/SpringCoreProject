package org.javaturk.spring.di.ch01.dependency.field;

public class Service {

}
