package org.javaturk.spring.di.ch01.dependency.method;

public class Service {

}
