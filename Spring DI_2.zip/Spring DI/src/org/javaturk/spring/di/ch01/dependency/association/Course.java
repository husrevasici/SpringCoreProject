package org.javaturk.spring.di.ch01.dependency.association;

public class Course {
	
	private Professor instructor;

}
