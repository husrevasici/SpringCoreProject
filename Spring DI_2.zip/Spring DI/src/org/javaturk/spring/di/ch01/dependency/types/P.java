package org.javaturk.spring.di.ch01.dependency.types;

public class P {

}
