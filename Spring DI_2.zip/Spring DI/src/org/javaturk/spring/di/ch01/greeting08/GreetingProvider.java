package org.javaturk.spring.di.ch01.greeting08;

public interface GreetingProvider {
	
	public String getGreeting();
}
