package org.javaturk.spring.di.ch03.domain;

public abstract class AbstractClassAC {

}
