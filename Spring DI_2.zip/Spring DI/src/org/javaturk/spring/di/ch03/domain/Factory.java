package org.javaturk.spring.di.ch03.domain;

public interface Factory {
	BeanA create();
}
