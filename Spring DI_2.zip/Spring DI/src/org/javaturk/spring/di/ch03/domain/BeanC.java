package org.javaturk.spring.di.ch03.domain;

public class BeanC {

	@Override
	public String toString() {
		return "BeanC";
	}
}
