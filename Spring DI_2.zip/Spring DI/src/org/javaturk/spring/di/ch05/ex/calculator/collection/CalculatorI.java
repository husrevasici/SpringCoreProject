
package org.javaturk.spring.di.ch05.ex.calculator.collection;

public interface CalculatorI {

	public double doCalculation(double argument);
}
