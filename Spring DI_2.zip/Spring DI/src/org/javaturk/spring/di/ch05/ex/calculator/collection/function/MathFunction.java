
package org.javaturk.spring.di.ch05.ex.calculator.collection.function;

public interface MathFunction {
	public double calculate(double arg);
}
