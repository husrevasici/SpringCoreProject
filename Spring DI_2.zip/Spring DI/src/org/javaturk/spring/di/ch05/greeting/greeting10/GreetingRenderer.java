package org.javaturk.spring.di.ch05.greeting.greeting10;

public interface GreetingRenderer {
	
	public void render();

}
