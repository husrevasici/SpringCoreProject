package org.javaturk.spring.di.ch05.greeting.greeting09;

public interface GreetingProvider {
	
	public String getGreeting();
}
