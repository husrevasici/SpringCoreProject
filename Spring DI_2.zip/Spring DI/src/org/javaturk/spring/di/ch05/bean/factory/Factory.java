package org.javaturk.spring.di.ch05.bean.factory;

import org.javaturk.spring.di.ch04.domain.BeanA;

public interface Factory {
	BeanA create();
}
