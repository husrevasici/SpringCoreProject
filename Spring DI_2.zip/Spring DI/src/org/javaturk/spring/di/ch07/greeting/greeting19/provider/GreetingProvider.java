package org.javaturk.spring.di.ch07.greeting.greeting19.provider;

public interface GreetingProvider {
	
	public String getGreeting();
}
