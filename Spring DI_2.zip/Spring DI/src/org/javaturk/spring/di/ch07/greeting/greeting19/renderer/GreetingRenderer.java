package org.javaturk.spring.di.ch07.greeting.greeting19.renderer;

public interface GreetingRenderer {
	
	public void render();

}
