package org.javaturk.spring.di.ch07.greeting.greeting17.renderer;

public interface GreetingRenderer {
	
	public void render();

}
