package org.javaturk.spring.di.ch07.greeting.greeting18.renderer;

public interface GreetingRenderer {
	
	public void render();

}
