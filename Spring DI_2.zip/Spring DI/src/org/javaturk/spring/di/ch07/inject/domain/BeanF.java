package org.javaturk.spring.di.ch07.inject.domain;

import org.springframework.stereotype.Component;

@Component
public class BeanF {

	@Override
	public String toString() {
		return "BeanF []";
	}
}
