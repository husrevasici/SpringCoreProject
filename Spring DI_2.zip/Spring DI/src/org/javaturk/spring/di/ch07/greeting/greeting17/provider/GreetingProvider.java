package org.javaturk.spring.di.ch07.greeting.greeting17.provider;

public interface GreetingProvider {
	
	public String getGreeting();
}
