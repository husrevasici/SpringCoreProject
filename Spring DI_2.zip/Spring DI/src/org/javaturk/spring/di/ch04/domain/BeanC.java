package org.javaturk.spring.di.ch04.domain;

public class BeanC {

	@Override
	public String toString() {
		return "BeanC";
	}
}
