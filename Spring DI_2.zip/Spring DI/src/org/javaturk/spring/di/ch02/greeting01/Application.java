package org.javaturk.spring.di.ch02.greeting01;

public class Application {

	public static void main(String[] args) {
		System.out.println("Hello world :)");
	}
}
