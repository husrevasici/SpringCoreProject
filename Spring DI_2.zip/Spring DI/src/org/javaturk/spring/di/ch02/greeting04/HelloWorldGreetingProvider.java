package org.javaturk.spring.di.ch02.greeting04;

public class HelloWorldGreetingProvider implements GreetingProvider{
	
	public String getGreeting() {
		return "Hello World :)";
	}
}
