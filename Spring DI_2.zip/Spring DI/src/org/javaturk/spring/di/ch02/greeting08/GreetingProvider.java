package org.javaturk.spring.di.ch02.greeting08;

public interface GreetingProvider {
	
	public String getGreeting();
}
