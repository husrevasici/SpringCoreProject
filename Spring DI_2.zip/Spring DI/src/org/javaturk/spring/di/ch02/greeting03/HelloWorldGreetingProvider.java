package org.javaturk.spring.di.ch02.greeting03;

public class HelloWorldGreetingProvider {
	
	public String getGreeting() {
		return "Hello World :)";
	}
}
