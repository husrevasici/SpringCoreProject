package org.javaturk.spring.di.ch02.greeting06;

public class SelamGreetingProvider implements GreetingProvider{
	
	public String getGreeting() {
		return "Selam :)";
	}
}
