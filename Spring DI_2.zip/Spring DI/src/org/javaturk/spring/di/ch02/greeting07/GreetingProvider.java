package org.javaturk.spring.di.ch02.greeting07;

public interface GreetingProvider {
	
	public String getGreeting();
}
