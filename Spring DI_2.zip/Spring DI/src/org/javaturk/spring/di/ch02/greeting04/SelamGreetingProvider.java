package org.javaturk.spring.di.ch02.greeting04;

public class SelamGreetingProvider implements GreetingProvider{
	
	public String getGreeting() {
		return "Selam :)";
	}
}
