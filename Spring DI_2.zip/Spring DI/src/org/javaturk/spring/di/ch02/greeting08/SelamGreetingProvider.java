package org.javaturk.spring.di.ch02.greeting08;

public class SelamGreetingProvider implements GreetingProvider{
	
	public String getGreeting() {
		return "Selam :)";
	}
}
