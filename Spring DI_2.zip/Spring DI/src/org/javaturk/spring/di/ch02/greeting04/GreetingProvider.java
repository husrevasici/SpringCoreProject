package org.javaturk.spring.di.ch02.greeting04;

public interface GreetingProvider {
	
	public String getGreeting();
}
