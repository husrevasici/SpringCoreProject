package org.javaturk.spring.di.ch06.greeting.greeting12.renderer;

public interface GreetingRenderer {
	
	public void render();

}
