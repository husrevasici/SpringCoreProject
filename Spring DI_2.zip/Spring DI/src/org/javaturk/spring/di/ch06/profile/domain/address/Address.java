package org.javaturk.spring.di.ch06.profile.domain.address;

public interface Address {
	
	String getAddress();

}
