
package org.javaturk.spring.di.ch06.ex.calculator.qualifier;

public interface CalculatorI {

	public double doCalculation(double argument);
}
