package org.javaturk.spring.di.ch06.greeting.greeting13.provider;

public interface GreetingProvider {
	
	public String getGreeting();
}
