package org.javaturk.spring.di.ch06.autowired.domain;

public class BeanD {
	
	@Override
	public String toString() {
		return "BeanD [ ]";
	}
}
