package org.javaturk.spring.di.ch06.greeting.greeting11;

public interface GreetingProvider {
	
	public String getGreeting();
}
