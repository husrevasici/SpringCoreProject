package org.javaturk.spring.di.ch06.greeting.greeting15.provider;

public interface GreetingProvider {
	
	public String getGreeting();
}
