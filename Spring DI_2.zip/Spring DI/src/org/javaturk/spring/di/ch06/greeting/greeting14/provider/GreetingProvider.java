package org.javaturk.spring.di.ch06.greeting.greeting14.provider;

public interface GreetingProvider {
	
	public String getGreeting();
}
