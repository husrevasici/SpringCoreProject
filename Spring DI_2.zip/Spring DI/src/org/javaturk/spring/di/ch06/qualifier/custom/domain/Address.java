package org.javaturk.spring.di.ch06.qualifier.custom.domain;

public interface Address {
	
	String getAddress();

}
