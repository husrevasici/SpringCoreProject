package org.javaturk.spring.di.ch06.greeting.greeting14.renderer;

public interface GreetingRenderer {
	
	public void render();

}
