package org.javaturk.spring.di.ch06.greeting.greeting15.renderer;

public interface GreetingRenderer {
	
	public void render();

}
