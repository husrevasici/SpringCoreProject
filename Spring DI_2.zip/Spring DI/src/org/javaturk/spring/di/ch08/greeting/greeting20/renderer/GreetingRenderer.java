package org.javaturk.spring.di.ch08.greeting.greeting20.renderer;

public interface GreetingRenderer {
	
	public void render();

}
