package org.javaturk.spring.di.ch08.lifecycle.applicationContext.domain1;

import org.springframework.stereotype.Component;

@Component
public class BeanD {

	@Override
	public String toString() {
		return "BeanD []";
	}
}
