package org.javaturk.spring.di.ch08.greeting.greeting20.provider;

public interface GreetingProvider {
	
	public String getGreeting();
}
