package org.javaturk.spring.di.ch08.priority.domain;

public interface MyBean {
	
}
