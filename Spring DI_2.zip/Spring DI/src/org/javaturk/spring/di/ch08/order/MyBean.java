package org.javaturk.spring.di.ch08.order;

public interface MyBean {
	
}
