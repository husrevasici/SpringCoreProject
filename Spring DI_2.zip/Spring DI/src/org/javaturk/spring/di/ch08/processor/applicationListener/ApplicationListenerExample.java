package org.javaturk.spring.di.ch08.processor.applicationListener;

public class ApplicationListenerExample {

}
