package org.javaturk.spring.di.ch08.processor.beanFactoryPostProcessor;

public class BeanFactoryPostProcessorExample {

}
